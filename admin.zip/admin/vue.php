<?php

echo "Please insert this shortcode anywhere on this page [donate]My Text Here[/donate]";